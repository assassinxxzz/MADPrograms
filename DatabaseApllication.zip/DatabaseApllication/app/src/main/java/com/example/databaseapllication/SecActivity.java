package com.example.databaseapllication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class SecActivity extends AppCompatActivity
{
    TextView textViewResult;
    SharedPreferences sharedPreferences;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.second_activity);

        textViewResult = findViewById (R.id.result);
        sharedPreferences = getSharedPreferences ("myPref",MODE_PRIVATE);
        String username = sharedPreferences.getString ("username","user");
        String password = sharedPreferences.getString ("password","password");
        textViewResult.setText ("Hello" + username);
    }

}
