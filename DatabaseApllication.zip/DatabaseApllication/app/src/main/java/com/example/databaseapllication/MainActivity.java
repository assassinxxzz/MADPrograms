package com.example.databaseapllication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText editTextusername;
    EditText editTextpassword;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        EdgeToEdge.enable (this);
        setContentView (R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener (findViewById (R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets (WindowInsetsCompat.Type.systemBars ());
            v.setPadding (systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextusername = findViewById (R.id.username);
        editTextpassword = findViewById (R.id.password);

        sharedPreferences = getSharedPreferences ("mypref",MODE_PRIVATE);
        editor = sharedPreferences.edit ();
    }

    public void login(View view)
    {
        String username = editTextusername.getText ().toString ();
        String password = editTextpassword.getText ().toString ();

        editor.putString ("username",username);
        editor.putString ("password",password);

        editor.commit ();

        Intent intent = new Intent (MainActivity.this,SecActivity.class);
        startActivity (intent);
    }
}