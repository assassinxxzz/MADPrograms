package com.example.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.TextView;

public class AeroPlaneMode extends BroadcastReceiver
{
    TextView textView;
    AeroPlaneMode()
    {

    }
    AeroPlaneMode(TextView textView)
    {
        this.textView = textView;
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean airplanemodeOn = intent.getBooleanExtra("state", false);
        if (airplanemodeOn) {
            textView.setText("Airplane mode is on");
        } else {
            textView.setText("Airplane mode is off");
        }
    }
}
