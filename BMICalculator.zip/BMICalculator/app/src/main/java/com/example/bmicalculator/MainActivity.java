package com.example.bmicalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText weightvalue,heightvalue;
    Button button;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        weightvalue = findViewById(R.id.enterweight);
        heightvalue = findViewById(R.id.enterheight);
        button = findViewById(R.id.button2);
        result = findViewById(R.id.result);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Float wt = Float.parseFloat(weightvalue.getText().toString());
                Float htm = Float.parseFloat(heightvalue.getText().toString())/100;
                Float bmi = wt / (htm * htm);
                if(bmi<18.5)
                {
                    result.setText("The BMI is: "+bmi+"\nUnder Weight");
                }
                else if (bmi>=18.5 && bmi<24.9)
                {
                    result.setText("The BMI is: "+bmi+"\nHealthy");
                }
                else if (bmi>=24.9 && bmi<30)
                {
                    result.setText("The BMI is: "+bmi+"\nOver Weight");
                }
                else
                {
                    result.setText("The BMI is: "+bmi+"\nSuffering from Obesity");
                }
            }
        });
    }
}