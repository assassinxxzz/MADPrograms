package com.example.movieticketbookingsp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    EditText count;
    Spinner list;
    Button sub;
    String movies[] = {"Jawan","Leo","Tiger3","Ghost"};
    int selectedPos;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        count = findViewById(R.id.ticketsctBox);
        list = findViewById(R.id.movieslist);
        sub = findViewById(R.id.submitBtn);
        ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,movies);
        list.setAdapter(adapter);
        list.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPos = position;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences = getSharedPreferences("MyPreferences",MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("MovieName",selectedPos);
                editor.putInt("TicketsCount",Integer.parseInt(count.getText().toString()));
                editor.apply();
                Toast.makeText(MainActivity.this, "Saved Successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sh = getSharedPreferences("MyPreferences",MODE_PRIVATE);
        int spos = sh.getInt("MovieName",0);
        int ct = sh.getInt("TicketsCount",0);
        list.setSelection(spos);
        count.setText(String.valueOf(ct));
    }
}