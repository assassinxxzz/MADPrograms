package com.example.arithmeticoperations;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity
{
    EditText value1,value2;
    Button add,sub,mul,div;
    TextView res;
    Double a,b;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        value1 = findViewById(R.id.valuefora);
        value2 = findViewById(R.id.valueforb);
        add = findViewById(R.id.buttonadd);
        sub = findViewById(R.id.buttonsub);
        mul = findViewById(R.id.buttonmul);
        div = findViewById(R.id.buttondiv);
        res = findViewById(R.id.result);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Double.parseDouble(value1.getText().toString());
                b = Double.parseDouble(value2.getText().toString());
                res.setText("Result: "+(a+b));
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Double.parseDouble(value1.getText().toString());
                b = Double.parseDouble(value2.getText().toString());
                res.setText("Result: "+(a-b));
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Double.parseDouble(value1.getText().toString());
                b = Double.parseDouble(value2.getText().toString());
                res.setText("Result: "+(a*b));
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Double.parseDouble(value1.getText().toString());
                b = Double.parseDouble(value2.getText().toString());
                if(b!=0)
                    res.setText("Result: "+(a/b));
                else
                    res.setText("Division not possible");
            }
        });
    }
}