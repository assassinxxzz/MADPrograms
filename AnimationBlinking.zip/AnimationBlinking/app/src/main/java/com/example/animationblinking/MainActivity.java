package com.example.animationblinking;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button blink,rotate,fade,move,slide,zoom;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        EdgeToEdge.enable (this);
        setContentView (R.layout.activity_main);
        imageView = findViewById (R.id.imageView);
        blink = findViewById (R.id.button);
        rotate = findViewById (R.id.button2);
        fade = findViewById (R.id.button3);
        move = findViewById (R.id.button4);
        slide = findViewById (R.id.button5);
        zoom = findViewById (R.id.button6);

        blink.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation (getApplicationContext (),R.anim.blink);//this is not accepted in annonymous class
                // set the image on blink button

                imageView.startAnimation (animation);
            }
        });

        rotate.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation (getApplicationContext (), R.anim.rotate);
                imageView.startAnimation (animation);
            }
        });

        fade.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation (getApplicationContext (), R.anim.fade);
                imageView.startAnimation (animation);
            }
        });

        move.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation (getApplicationContext (), R.anim.move);
                imageView.startAnimation (animation);
            }
        });

        slide.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation (getApplicationContext (), R.anim.slide);
                imageView.startAnimation (animation);
            }
        });

        zoom.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation (getApplicationContext (), R.anim.zoom);
                imageView.startAnimation (animation);
            }
        });
    }
}